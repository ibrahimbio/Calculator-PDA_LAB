import React, {useEffect, useState} from 'react';
import Calculator from './containers/Calculator';
import './App.css';

function App() {


  return (
    <Calculator />
  );
}

export default App;